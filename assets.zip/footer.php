		<script type="text/javascript" src="assets/easy-social-share-buttons.js"></script>
		<script type="text/javascript" src="assets/skip-link-focus-fix.js"></script>
<footer>
	<div class="container footerWrap">
		<div class="row">
			<div class="col-xs-12 col-sm-3">
					<h4>techponya.com</h4>
						<ul class="list-unstyled">
							<li><a href="<?php echo techponya_url(); ?>user">Konstributor</a></li>
							<li><a href="https://techponya.com/affiliate">Affiliates</a></li>
							<li><a href="https://techponya.com/about">About Us</a></li>
							<li><a href="https://techponya.com/feed">RSS Feed</a></li>
						</ul>
				</div>
				<div class="col-xs-12 col-sm-3">
					<h4>Help &amp; Support</h4>
					<ul class="list-unstyled">
						<li><a href="https://techponya.com/faq">FAQ</a></li>
						<li><a href="https://techponya.com/submission-guidelines">Submission Guidelines</a></li>
						<li><a href="https://techponya.com/payment-rates">Payment Rates</a></li>
						<li><a href="https://techponya.com/contact-support">Contact Support</a></li>
					</ul>
				</div>
				<div class="col-xs-12 col-sm-3">
					<h4>Resources</h4>
					<ul class="list-unstyled">
						<li><a href="https://stocksnap.io/" target="_blank">Free Stock Photos</a></li>
						<li><a href="https://techponya.com/blog">Blog</a></li>
						<li><a href="https://techponya.com/blog/bootstrap-resources/">Resource List</a></li>
						<li><a href="https://techponya.com/blog/category/tutorials/">Tutorials</a></li>
					</ul>
				</div>
				<div class="col-xs-12 col-sm-3">
					<h4>Social</h4>
					<ul class="list-unstyled">
						<li><a href="https://www.facebook.com/techponya" target="_blank">Facebook</a></li>
						<li><a href="https://twitter.com/techponya" target="_blank">Twitter</a></li>
						<li><a href="http://www.youtube.com/user/techponyaofficial" target="_blank">YouTube</a></li>
						<li><a href="https://plus.google.com/+techponyaThemes/posts" target="_blank">Google+</a></li>
					</ul>
				</div>
			</div>
		</div>

		<div class="subFooter">
			<div class="container">
				<div class="row">
					<div class="col-xs-12">
						<div class="pull-left">
						© 2016 <a href="<?php echo techponya_url(); ?>" target="_blank">Techponya.ga</a> / 
						<a href="https://techponya.com/licenses">Licenses</a> / 
						<a href="https://techponya.com/terms">Terms &amp; Conditions</a> / 
						<a href="https://techponya.com/privacy">Privacy Policy</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</footer>