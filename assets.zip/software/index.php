<?php include "../header.php";?>
<div class="site-content">
		<div class="container main-content-area">
			<div class="row">
		<div id="secondary" class="widget-area col-sm-12 col-md-4" role="complementary">
			<div class="well">
				<aside id="popular-themes-2" class="widget popular-themes"><h3 class="widget-title">Popular Themes</h3>
				<!-- social icons -->
				<div class="popular-themes sticky-sidebar-popular-themes">
				<ul>
					<li class="theme_item"><a class="theme_img" href="#/theme/thema-bootstrap-admin-template-B0C6F9A" title="Thema - Bootstrap Admin Template">
						<img src="<?php echo techponya_url(); ?>assets/B0C6F9A.png" alt="Thema - Bootstrap Admin Template"></a>
						<a class="theme_title" href="#/theme/thema-bootstrap-admin-template-B0C6F9A" title="Thema - Bootstrap Admin Template">Thema - Bootstrap Admin Template</a>
					</li>
					<li class="theme_item"><a class="theme_img" href="#/theme/cayman-html-multipurpose-template-BB4D11C" title="Cayman - HTML MultiPurpose Template">
						<img src="<?php echo techponya_url(); ?>assets/BB4D11C.png" alt="Cayman - HTML MultiPurpose Template"></a>
						<a class="theme_title" href="#/theme/cayman-html-multipurpose-template-BB4D11C" title="Cayman - HTML MultiPurpose Template">Cayman - HTML MultiPurpose Template</a>
					</li>
					<li class="theme_item"><a class="theme_img" href="#" title="Repute - Responsive Multipurpose Theme">
						<img src="<?php echo techponya_url(); ?>assets/B2A2516.png" alt="Repute - Responsive Multipurpose Theme"></a>
						<a class="theme_title" href="#" title="Repute - Responsive Multipurpose Theme">Repute - Responsive Multipurpose Theme</a>
					</li>
					<li class="theme_item"><a class="theme_img" href="#" title="Ultimate Blocks - Bootstrap Theme Builder">
						<img src="<?php echo techponya_url(); ?>assets/B1559F1.png" alt="Ultimate Blocks - Bootstrap Theme Builder"></a>
						<a class="theme_title" href="#" title="Ultimate Blocks - Bootstrap Theme Builder">Ultimate Blocks - Bootstrap Theme Builder</a></li>
					<li class="theme_item"><a class="theme_img" href="#" title="Arillo - Responsive Real Estate Theme">
						<img src="<?php echo techponya_url(); ?>assets/B1E78AA.png" alt="Arillo - Responsive Real Estate Theme"></a>
						<a class="theme_title" href="#" title="Arillo - Responsive Real Estate Theme">Arillo - Responsive Real Estate Theme</a></li>
				</ul>	
						<div class="more_themes">
						<a href="https://bootstrapbay.com/popular?utm_source=blog" class="btn btn-primary btn-sm">View more popular themes »</a>
				</div>
				</div><!-- end social icons -->
			</aside>
			</div>
		</div>
		<div id="content" class="main-content-inner col-sm-12 col-md-8 pull-left">
			<div id="primary" class="content-area">
			<main id="main" class="site-main" role="main">
			<div class="row main-content-inner">
				<div class="col-md-12">

					<div class="type-post hentry">
						<div class="row">
							<div class="col-md-9 cta-contents">
								<a href="#googlechrome" title="Google Chrome" target="_self">
									<img src="<?php echo techponya_url(); ?>assets/741-featured-60x60.jpg" width="50" height="50" title="Google Chrome" alt="21 Amazing Sites With Breathtaking Free Stock Photos" class="wpp-thumbnail wpp_cached_thumb wpp_featured"></a>
									<h1 class="entry-title">Google Chrome <small>v10.0.0.1</small></h1>
							</div>
							<div class="col-md-3 cta-button">
								<a href="<?php echo techponya_url(); ?>software/googlechrome" class="btn btn-lg btn-block btn-info">Download</a>
							</div>
						 </div>
					</div>
					<div class="type-post hentry">
						<div class="row">
							<div class="col-md-9 cta-contents">
								<a href="#googlechrome" title="Google Chrome" target="_self">
									<img src="http://localhost/techponya/assets/741-featured-60x60.jpg" width="50" height="50" title="Google Chrome" alt="21 Amazing Sites With Breathtaking Free Stock Photos" class="wpp-thumbnail wpp_cached_thumb wpp_featured"></a>
									<h1 class="entry-title">Google Chrome <small>v10.0.0.1</small></h1>
							</div>
							<div class="col-md-3 cta-button">
								<a href="#" class="btn btn-lg btn-block btn-info">Download</a>
							</div>
						 </div>
					</div>
					<div class="type-post hentry">
						<div class="row">
							<div class="col-md-9 cta-contents">
								<a href="#" title="Google Chrome" target="_self">
									<img src="http://localhost/techponya/assets/741-featured-60x60.jpg" width="50" height="50" title="Google Chrome" alt="21 Amazing Sites With Breathtaking Free Stock Photos" class="wpp-thumbnail wpp_cached_thumb wpp_featured"></a>
									<h1 class="entry-title">Google Chrome <small>v10.0.0.1</small></h1>
							</div>
							<div class="col-md-3 cta-button">
								<a href="#" class="btn btn-lg btn-block btn-info">Download</a>
							</div>
						 </div>
					</div>
					<div class="type-post hentry">
						<div class="row">
							<div class="col-md-9 cta-contents">
								<a href="#" title="Google Chrome" target="_self">
									<img src="http://localhost/techponya/assets/741-featured-60x60.jpg" width="50" height="50" title="Google Chrome" alt="21 Amazing Sites With Breathtaking Free Stock Photos" class="wpp-thumbnail wpp_cached_thumb wpp_featured"></a>
									<h1 class="entry-title">Google Chrome <small>v10.0.0.1</small></h1>
							</div>
							<div class="col-md-3 cta-button">
								<a href="#" class="btn btn-lg btn-block btn-info">Download</a>
							</div>
						 </div>
					</div>
            </div>
        </div>
	</div>
</div>    
	</div><!-- close .*-inner (main-content or sidebar, depending if sidebar is used) -->
		</div><!-- close .row -->
	</div><!-- close .container -->
	</div><!-- close .main-content -->
		<?php include "../footer.php" ?>
<a href="javascript:void(0);" title="SumoMe" style="position: fixed; z-index: 2147483647; padding: 0px; width: 44px; height: 40px; text-indent: -10000px; display: none !important; background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyRpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NTY2MSwgMjAxMi8wMi8wNi0xNDo1NjoyNyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNiAoTWFjaW50b3NoKSIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDpBNjE1OTIxRTcwNzUxMUUzQkUxRkIxNEU0NUM0RjM4OCIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDpBNjE1OTIxRjcwNzUxMUUzQkUxRkIxNEU0NUM0RjM4OCI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOkUzQjQyQzRENzA3NDExRTNCRTFGQjE0RTQ1QzRGMzg4IiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOkUzQjQyQzRFNzA3NDExRTNCRTFGQjE0RTQ1QzRGMzg4Ii8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+t9pejAAAAWRJREFUeNrslz1Lw1AUhhOlYhXFiEt/gIigm+isg5sOjs7+D/+HY91ENxGRxFLxY+zWSRCdHMQ6OTgYnwsnEEppTtMEAp4DL29yuefcJ/fk9sOP49irckx4FQ8DNEADNEADNMD/CvjV6x0j9QMwdx11nY+Q47t18u7gMjqlQE0Dh92iVefcbyhyJrETtJIXMEKH6IJi0wq4JRlyHjG+lQHXREeSmxvQxR66ouicAi6JeYHcGZAzhZ3Jw6fXGQ1wIQjesGe53UYhxRcVcEnMokvm7fbBnaMDGXplnZdxTnGYut5EbRZpSPvaQ+CSqAvkPprh+lo6Mqh+LsD+7V9DD+gGBcrDWpNde5ROpKOVlewP+08iLf1w80r6mGvQ4vfcO0jyJ9YpCa6bBaf9JolKAmxpJmkAw5IAw6IA79FPwXC/6K4QQN6Tb+ypYMCOvN/eWKfYfm4ZoAEaoAEaoAEaYOUB/wQYAATRi8cPOM7SAAAAAElFTkSuQmCC&quot;); background-color: rgb(15, 82, 186); background-position-x: 4px; background-repeat: no-repeat;"></a>
</body>
</html>