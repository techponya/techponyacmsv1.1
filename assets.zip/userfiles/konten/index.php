<?php 
 header('location:../../index'); 
?>