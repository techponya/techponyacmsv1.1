<?php
function techponya_url() {
	return 'http://localhost/blog/';
}
function widget_url() {
	return 'http://localhost/blog/widget.php';
}
?>