<?php
session_start();
	if(!isset($_SESSION['username'])) {
	   header('location:login.php'); 
	} else { 
	   $username = $_SESSION['username']; 
	}
    ini_set("display_errors",1);
 
 include "konten/header.php";
?>
<div align='center'>
   Selamat Datang, <b><?php echo $username;?></b> <a href="logout.php"><b>Logout</b></a>
</div>
<hr>
<div class="container">
    <div class="row">
        <div class="col-md-9">
			<?php
				 if(isset($_POST['posting'])){
						require '../koneksi.php';
						$Destination = '../userfiles/konten';
						if(!isset($_FILES['ImageFile']) || !is_uploaded_file($_FILES['ImageFile']['tmp_name'])){
							$NewImageName= 'default.jpg';
							move_uploaded_file($_FILES['ImageFile']['tmp_name'], "$Destination/$NewImageName");
						}
						else{
							$RandomNum = rand(0, 9999999999);
							$ImageName = str_replace(' ','-',strtolower($_FILES['ImageFile']['name']));
							$ImageType = $_FILES['ImageFile']['type'];
							$ImageExt = substr($ImageName, strrpos($ImageName, '.'));
							$ImageExt = str_replace('.','',$ImageExt);
							$ImageName = preg_replace("/\.[^.\s]{3,4}$/", "", $ImageName);
							$NewImageName = $ImageName.'-'.$RandomNum.'.'.$ImageExt;
							move_uploaded_file($_FILES['ImageFile']['tmp_name'], "$Destination/$NewImageName");
						}
						$q=mysql_query("Insert into artikel (`kategori`,`judul`,`isi`,`gambar`,`seo_title`,`tanggal`,`penulis`) values 
						('".$_POST['kategori']."','".$_POST['judul']."','".$_POST['editor1']."','".$NewImageName."','".$_POST['seotitle']."','".date("Y-m-d H:i:s")."','".$_POST['penulis1']."')") or die(mysql_error());
						
						if($q)
						{
							echo "<div class='alert alert-success' role='alert'>
							<strong>Berhasil!!</strong> Artikel yang anda tulis berhasil di publikasikan.
							</div>";
						}
					}
				?>
				<h1 class="page-header">
                    <span class="label label-success"><?php echo $username;?> <small>Buat Artikel Baru</small></span>
                </h1>
				<script src="../fitur/ckeditor/ckeditor.js"></script>
				<form action="" method="post" enctype="multipart/form-data">
				<label>Judul <span class="text-danger">*</span></label>
				<input class="form-control" name="judul" id="slug-source" />
				<p></p>
				<label>SEO Title <span class="text-danger">*</span></label>
				<input class="form-control" name="seotitle" value="" id="slug-target" />
					<script src="plugin/slugify/jquery.min.js"></script>
					<script src="plugin/slugify/slugify.js"></script>
					<script>
						jQuery(function($) {
						  $('#slug-target,#slug-target-span').slugify('#slug-source'); // Type as you slug
						});
					</script>
				<p></p>
				<label for="kategori">Kategori</label>
					<select class="form-control" name="kategori" id="kategori">
					    <option value="select"></option>
						<option value="software">Software</option>
						<option value="games">Games</option>
						<option value="technews">Tech News</option>
						<option value="tipstrik">Tips & Trik</option>
				</select>
				<p></p>
				<label>Konten <span class="text-danger">*</span></label>
				<textarea id="editor1" name="editor1" rows="10" cols="80"></textarea>
				<p></p>
				<label>File: <span class="text-danger">*</span></label>
				<input type="file" name="ImageFile" />
				<p></p>
				<input type="hidden" name="penulis1" value="<?php echo $username;?>" />
				<input class="btn btn-primary" type="submit" name="posting" value="POSTING"  />
				</form>
						<script type="text/javascript">


				if ( typeof CKEDITOR == 'undefined' )
				{
					document.write(
						'CKEditor not found');
				}
				else
				{
					var editor = CKEDITOR.replace( 'editor1' );	

					
					CKFinder.setupCKEditor( editor, '' ) ;

					
				}
				</script>
		<hr>
		</div>
			<?php include "konten/widget.php"; ?>
			<!-- Side Widget Well -->
                <div class="well">
                    <h4><?php echo $username;?></h4>
                    <li>
						<a href="logout.php">Logout</a>
                    </li>
                </div>
			</div>
        </div>
		<hr>

        <footer>
            <div class="row">
                <div class="col-lg-12">
                    <p>Copyright &copy; Your Website 2014</p>
                </div>
            </div>
        </footer>
	</div>    
	
	
	<!-- jQuery -->
    <script src="layout/home/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="layout/home/js/bootstrap.min.js"></script>

</body>

</html>