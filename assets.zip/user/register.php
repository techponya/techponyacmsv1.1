<?php
   session_start();
   if(isset($_SESSION['username'])) {
   header('location:index.php'); }
   require_once "class/recaptchalib.php";
?>
<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<title>Register - Techponya</title>
		
		<link href="layout/login/css/style.css" rel="stylesheet" type="text/css">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<style type="text/css"></style><script async="" src="http://www.google-analytics.com/analytics.js"></script>
		<script src='https://www.google.com/recaptcha/api.js'></script>
		<!--webfonts-->
		<link href="layout/login/css/css" rel="stylesheet" type="text/css">
		<!--//webfonts-->
</head>
<body>
	 <div class="main">
		<div class="login-form">
			<h1>Register</h1>
					<div class="head">
						<img src="layout/login/images/user.png" alt="avatar">
					</div>
				<form action="user-register.php" method="post">
						<input name="username" type="text" class="text" value="USERNAME" onfocus="this.value = &#39;&#39;;" onblur="if (this.value == &#39;&#39;) {this.value = &#39;USERNAME&#39;;}">
						<input name="password" type="password" value="Password" onfocus="this.value = &#39;&#39;;" onblur="if (this.value == &#39;&#39;) {this.value = &#39;Password&#39;;}">
						<div class="g-recaptcha" data-sitekey="6LcJZCETAAAAAHs0JYTkwZz5fEh2yMZ7p7EeEU7p"></div>
						<br>
						<div class="submit">
							<input type="submit" value="REGISTER">
					</div>	
					<p>Sudah Punya akun?  <a href="login.php"><b>Masuk</b></a></p>
				</form>
			</div>
   					<div class="copy-right">
						<p> © 2016 Techponya | All rights reserved</p>
					</div>
		</div>
</body>
</html>