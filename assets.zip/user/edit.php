<?php
session_start();
if(!isset($_SESSION['username'])) {
   header('location:login.php'); 
} else { 
   $username = $_SESSION['username']; 
}
include('../config.php');
//Buat konfigurasi upload
//Folder tujuan upload file
$eror		= false;
$folder		= '../konten/gambar/';
//type file yang bisa diupload
$file_type	= array('jpg','jpeg','png','gif','bmp');
//tukuran maximum file yang dapat diupload
$max_size	= 8000000; // 8MB
if(isset($_POST['posting'])){
	//Mulai memorises data
	$file_name	= $_FILES['data_upload']['name'];
	$file_size	= $_FILES['data_upload']['size'];
	//cari extensi file dengan menggunakan fungsi explode
	$explode	= explode('.',$file_name);
	$extensi	= $explode[count($explode)-1];

	//check apakah type file sudah sesuai
	if(!in_array($extensi,$file_type)){
		$eror   = true;
		$pesan .= '- Anda Harus memilih gambar<br />';
	}
	if($file_size > $max_size){
		$eror   = true;
		$pesan .= '- Gambar ditadak di bolehkan<br />';
	}
	//check ukuran file apakah sudah sesuai

	if($eror == true){
		echo '<div id="eror">'.$pesan.'</div>';
	}
	else{
		//mulai memproses upload file
		if(move_uploaded_file($_FILES['data_upload']['tmp_name'], $folder.$file_name)){
			//catat nama file ke database
			$q=mysql_query("Insert into artikel (`Gambar`,`Judul`,`Isi`,`FolderImg`,`DateUpload`,`penulis`) values 
			('".$file_name."','".$_POST['judul']."','".$_POST['editor1']."','".$folder."','".date('Y-m-d H:i:s')."','".$_POST['penulis']."')") or die(mysql_error());
			
			if($q)
			{
				echo "<script>alert('BERHASIL ditambahkan')</script>";
			}
		}
	}
}
?>
<?php include "konten/header.php";?>
<div align='center'>
   Selamat Datang, <b><?php echo $username;?></b> <a href="logout.php"><b>Logout</b></a>
</div>
<script src="../fitur/ckeditor/ckeditor.js"></script>
<form method="post" enctype="multipart/form-data" action="">
<label>Judul</label>
<input name="judul" cols="40" rows="5" />
<p></p>
<label>Konten</label>
<textarea id="editor1" name="editor1" rows="10" cols="40"></textarea>
<p></p>
<label>File</label>
<input type="file" name="data_upload" />
<p></p>
<input type="hidden" name="penulis" value="<?php echo $username;?>" />
<br>
<input type="submit" name="posting" value="POSTING">
</form>
<script type="text/javascript">
if ( typeof CKEDITOR == 'undefined' )
{
	document.write(
		'CKEditor not found');
}
else
{
	var editor = CKEDITOR.replace( 'editor1' );	

	
	CKFinder.setupCKEditor( editor, '' ) ;

	
}
</script>
	<!-- Techponya Footer -->
		<footer class="site-footer">
			<div class="container">
				<div class="row">
					<div class="col-sm-6">
						Copyright &copy; 2016 Techponya - All Rights Reserved. 
					</div>
				</div>
			</div>
		</footer>
		
	<!-- Techponya Footer Widgets -->
			<div class="container">
				 <div class="row">
					<div class="col-sm-6">
						<h4>Techponya</h4>
						<p>Solusi Internet Aplikasi dan Teknologi</p>
					</div>
					<div class="col-sm-3">
						<h5>Address</h5>
						<p>Jln. Perjuangan blok A<br />Bikeru, Sinjai Selatan<br />Indonesia</p>
					</div>
					<div class="col-sm-3">
						<h5>Contact</h5>
						<p>Phone: +62 81275192709<br />info@techponya.ga</p>
					</div>
				</div>
			</div>
	
    <!-- JavaScript -->
	<script src="assets/js/bootstrap.js"></script>
	<script src="assets/js/joinable.js"></script>
	<script src="assets/js/resizeable.js"></script>
</body>
</html>