	<div class="col-md-3">
                <div class="well">
                    <h4>Blog Categories</h4>
                    <div class="row">
                        <div class="col-lg-10">
							<h4>
							<li><a class="label label-info" href="index.php">Home User</a></li>
							</h4>
                            <h4>
							<li><a class="label label-success" href="buat.php">Buat Artikel</a></li>
							</h4>
                            <h4>
							<li><a class="label label-info" href="software.php">Upload Software</a></li>
							</h4>
							<h4>
							<li><a class="label label-info" href="games.php">Upload Games</a></li>
							</h4>
                        </div>
                    </div>
                </div>

                <!-- Side Widget Well -->
                <div class="well">
                    <h4>Side Widget Well</h4>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Inventore, perspiciatis adipisci accusamus laudantium odit aliquam repellat tempore quos aspernatur vero.</p>
                </div>