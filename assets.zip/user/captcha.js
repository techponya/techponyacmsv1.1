$(function(){

var captcha;


//membuat fungsi onloadCallback
onloadCallback=function(){
captcha=grecaptcha.render(document.getElementById('recaptcha'), {
   //masukan code sitekey disini
   'sitekey' : "6LdbrBwTAAAAABHQMlA02ZMj051Sdlrl_ogjw65e",
   'theme' : 'dark'
});
}


//mendaftarkan event  submit pada event handler .Dengan kata lain, ketika user menklik tombol kirim, blok code inilah yang akan dijalankan
$("form").on("submit",function(evt){


evt.preventDefault();    

var _this=$(this);
var nilai=_this.serialize();

$.ajax({
	type:_this.attr("method"),
	url: _this.attr("action"),
	data: nilai,
	cache: false,
	dataType: "json",
	success: function(a){
		if(a.status=="berhasil"){
			_this.find("input,textarea").val("");
			$(".alertBox").html("<span class='alert alert-success'>"+a.pesan+"</span>");
		} else {
			$(".alertBox").html("<span class='alert alert-danger'>"+a.pesan+"</span>");			

		}
	},
	error: function(a,b,c){
		console.log("Coba sekali lagi");
	},
	complete:function(){
        grecaptcha.reset(captcha);
	}
});


})

});