<?php
include("koneksi.php");
//menangkap variabel idbuku yang di kirim oleh view.php untuk di hapus
$id=$_GET[id];
 
//query untuk menghapus data
$query="delete from buku where idbuku='$id'";
$exe=mysql_query($query);
 
//laporan untuk data yang dihapus
//berhasil atau tidak data dihapus
if ($exe){
    echo "<script>alert('Data Berhasil Dihapus Boss')
    location.replace('index.php')</script>";
}else{
    echo "<script>alert('Data Gagal Dihapus Bos')
    location.replace('index.php')</script>";
}
?>