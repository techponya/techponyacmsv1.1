<?php
session_start();
if(!isset($_SESSION['username'])) {
   header('location:login.php'); 
} else { 
    $username = $_SESSION['username'];
}
include "../koneksi.php";
	//pagging
	$per_hal=5;
	$jumlah_record=mysql_query("SELECT COUNT(*) FROM artikel");
	$jum=mysql_result($jumlah_record, 0);
	$halaman=ceil($jum / $per_hal);
	$page=(isset($_GET['page'])) ? (int)$_GET['page'] : 1;
	$start= ($page - 1) * $per_hal;
	//
include "konten/header.php";
function custom_echo($x, $length)
		{
			  if(strlen($x)<=$length)
			  {
				echo $x;
			  }
			  else
			  {
				$y=substr($x,0,$length) . '...';
				echo $y;
			  }
		}
?>
<div class="container">
    <div class="row">
        <div class="col-md-9">
            <div class="panel panel-default panel-table">
              <div class="panel-heading">
                <div class="row">
                  <div class="col col-xs-6">
                    <h3 class="panel-title">Semua Blog</h3>
                  </div>
                  <div class="col col-xs-6 text-right">
					<a href="buat.php">
                    <button type="button" class="btn btn-sm btn-primary btn-create">Create New</button>
					</a>
                  </div>
                </div>
              </div>
              <div class="panel-body">
                <table class="table table-striped table-bordered table-list">
                  <thead>
                    <tr>
                        <th><em class="fa fa-cog"></em></th>
						<th>Gambar</th>
                        <th>Judul</th>
                        <th>Isi</th>
						<th>Penulis</th>
                    </tr> 
                  </thead>
                  <tbody>
							<?php
							$query=mysql_query("SELECT * FROM artikel limit $start, $per_hal");
							while ($techponya = mysql_fetch_row($query)){
							?>
                          <tr>
                            <td align="center">
                              <a class="btn btn-default"><em class="fa fa-pencil"></em></a>
                              <a class="btn btn-danger"><em class="fa fa-trash"></em></a>
							  <?php echo $techponya[6];?>
                            </td>
							<td> <img data-src="holder.js/200x200" alt="200x200" src="../userfiles/konten/<?php echo $techponya[4];?>" data-holder-rendered="true" style="width: 200px; height: 100px;"></td>
                            <td><?php custom_echo($techponya[2], 30); ?></td>
                            <td><?php custom_echo($techponya[3], 60); ?></td>
							<td><?php echo $techponya[7];?></td>
                          </tr>
                        </tbody>
						<?php } ?>
                </table>
              </div>
              <div class="panel-footer">
                <div class="row">
                  <div class="col col-xs-4">Page 1 of 5
                  </div>
                  <div class="col col-xs-8">
                    <ul class="pagination hidden-xs pull-right">
                     <li><a href="?page=<?php echo $page -1 ?>">«</a></li>
						<?php
							for($x=1; $x<=$halaman;$x++){
						?>
                        <li><a href="?page=<?php echo $x ?>"><?php echo $x ?> </a><?php } ?></li>
                    </ul>
                    <ul class="pagination visible-xs pull-right">
                        <li><a href="?page=<?php echo $page -1 ?>">«</a></li>
						<?php
							for($x=1; $x<=$halaman;$x++){
						?>
                        <li><a href="?page=<?php echo $x ?>">»<?php echo $x ?> </a><?php } ?></li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>

		</div>
			<?php include "konten/widget.php"; ?>
			</div>
        </div>
		<hr>

        <!-- Footer -->
        <footer>
            <div class="row">
                <div class="col-lg-12">
                    <p>Copyright &copy; Your Website 2014</p>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </footer>
	</div>    
	
	
	<!-- jQuery -->
    <script src="layout/home/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="layout/home/js/bootstrap.min.js"></script>

</body>

</html>