<?php 
include "koneksi.php";
$sql = "SELECT * FROM artikel order by RAND() LIMIT 5";
$hasil = mysql_query($sql,$dbconn);
?>
<div id="secondary" class="widget-area col-sm-12 col-md-4" role="complementary">
<div class="well">
<aside id="popular-themes-2" class="widget popular-themes"><h3 class="widget-title">Random Post</h3>
    <div class="popular-themes sticky-sidebar-popular-themes">
	<ul>
		<?php
			while ($techponya = mysql_fetch_row($hasil)){
		?>
		<li class="theme_item"><a class="theme_img" href="<?php echo techponya_url(); ?>artikel/<?php echo $techponya[5];?>" title="<?php custom_echo($techponya[2], 75); ?>">
			<img src="<?php echo techponya_url(); ?>userfiles/konten/<?php echo $techponya[4];?>" alt="<?php custom_echo($techponya[2], 75); ?>" width="350" height="140">
			<a class="theme_title" href="<?php echo techponya_url(); ?>artikel/<?php echo $techponya[5];?>" title="<?php custom_echo($techponya[2], 75); ?>"><?php custom_echo($techponya[2], 75); ?></a>
		</li>
		<?php } ?>
	</ul>	
			<div class="more_themes">
			<a href="https://bootstrapbay.com/popular?utm_source=blog" class="btn btn-primary btn-sm">View more popular themes »</a>
	</div>
    </div><!-- end social icons -->
</aside>
</div>