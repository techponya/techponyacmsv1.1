<?php include "funcations.php"; ?>
<!DOCTYPE html>
<!-- saved from url=(0030)https://bootstrapbay.com/blog/ -->
<html lang="en-US" prefix="og: http://ogp.me/ns#">
<!--<![endif]-->
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Solusi Internet Aplikasi dan Teknologi - Techponya</title>
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<link rel="pingback" href="https://bootstrapbay.com/blog/xmlrpc.php">

	<!-- favicon -->

	<link rel="shortcut icon" href="https://bootstrapbay.com/blog/wp-content/themes/techponya/inc/ico/favicon.ico">

	<!--[if IE]><![endif]-->

	
	<!-- This site is optimized with the Yoast SEO plugin v3.1.2 - https://yoast.com/wordpress/plugins/seo/ -->
	<meta name="description" content="Stay up to date with high quality content related to all things Bootstrap, web design &amp; web development.">
	<meta name="robots" content="noodp">
	<link rel="canonical" href="https://bootstrapbay.com/blog">
	<link rel="next" href="https://bootstrapbay.com/blog/page/2/">
	<meta property="og:locale" content="en_US">
	<meta property="og:type" content="website">
	<meta property="og:title" content="Techponya">
	<meta property="og:description" content="Stay up to date with high quality content related to all things Bootstrap, web design &amp; web development.">
	<meta property="og:url" content="https://bootstrapbay.com/blog">
	<meta property="og:site_name" content="Techponya">
		<script async="" src="assets/analytics.js"></script><script type="application/ld+json">{"@context":"http:\/\/schema.org","@type":"WebSite","url":"http:\/\/techponya.com\/\/","name":"Techponya","potentialAction":{"@type":"SearchAction","target":"https:\/\/techponya.com\/\/?s={search_term_string}","query-input":"required name=search_term_string"}}</script>
		<script src="assets/wp-emoji-release.min.js" type="text/javascript"></script>
		<style type="text/css">
			img.wp-smiley,
			img.emoji {
				display: inline !important;
				border: none !important;
				box-shadow: none !important;
				height: 1em !important;
				width: 1em !important;
				margin: 0 .07em !important;
				vertical-align: -0.1em !important;
				background: none !important;
				padding: 0 !important;
			}
		</style>
	<link rel="stylesheet" id="techponya-css" href="<?php echo techponya_url(); ?>assets/techponya.min.css" type="text/css" media="all">
	<link rel="stylesheet" id="advanced-responsive-video-embedder-css" href="<?php echo techponya_url(); ?>assets/advanced-responsive-video-embedder-public.css" type="text/css" media="all">
	<link rel="stylesheet" id="ce_responsive-css" href="<?php echo techponya_url(); ?>assets/video-container.css" type="text/css" media="all">
	<link rel="stylesheet" id="techponya-bootstrap-css" href="<?php echo techponya_url(); ?>assets/bootstrap.min.css" type="text/css" media="all">
	<link rel="stylesheet" id="techponya-icons-css" href="<?php echo techponya_url(); ?>assets/font-awesome.min.css" type="text/css" media="all">
	<link rel="stylesheet" id="techponya-icons-css" href="<?php echo techponya_url(); ?>assets/fonts/font-awesome.min.css" type="text/css" media="all">
	<link rel="stylesheet" id="techponya-fonts-css" href="<?php echo techponya_url(); ?>assets/css" type="text/css" media="all">
	<link rel="stylesheet" id="techponya-style-css" href="<?php echo techponya_url(); ?>assets/style.css" type="text/css" media="all">
	<link rel="stylesheet" id="techponya-custom-css" href="<?php echo techponya_url(); ?>assets/custom.css" type="text/css" media="all">
	<link rel="stylesheet" id="techponya-popular-posts-css" href="<?php echo techponya_url(); ?>assets/wpp.css" type="text/css" media="all">
		<script type="text/javascript" src="<?php echo techponya_url(); ?>assets/jquery.js"></script>
		<script type="text/javascript" src="<?php echo techponya_url(); ?>assets/jquery-migrate.min.js"></script>
		<script type="text/javascript" src="<?php echo techponya_url(); ?>assets/modernizr.min.js"></script>
		<script type="text/javascript" src="<?php echo techponya_url(); ?>assets/bootstrap.min.js"></script>
</head>
<body class="techponya home blog group-blog">
	<div id="techponya page" class="hfeed site">
		<header id="techponya-masthead" class="site-header" role="banner">
			<nav class="navbar techponya navbar-default" role="navigation">
				<div class="techponya container">
					<div class="techponya row">
						<div class="techponya-site col-sm-13">
							<div class="navbar-header">
								<button type="button" class="btn navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
									<span class="sr-only">Toggle navigation</span>
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
								</button>
								<div id="logo">
									<a href="<?php echo techponya_url(); ?>"><img src="<?php echo techponya_url(); ?>assets/logo.png" alt="Techponya"></a>
								</div><!-- end of #logo -->
							</div>
							<div class="collapse navbar-collapse navbar-ex1-collapse">
								<ul id="menu-primary-navigation" class="nav navbar-nav">
									<li id="techponya-item nav-1" class="techponya-menu-1">
										<a title="Software" href="<?php echo techponya_url(); ?>software">Software</a></li>
									<li id="techponya-item nav-3" class="techponya-menu-2">
										<a title="Games" href="<?php echo techponya_url(); ?>games">Games</a></li>
									<li id="techponya-item nav-4" class="techponya-menu-3">
										<a title="Tech News" href="<?php echo techponya_url(); ?>kategori/technews">Tech News</a></li>
									<li id="techponya-item nav-5" class="techponya-menu-4">
										<a title="Tips & Trik" href="<?php echo techponya_url(); ?>kategori/tipstrik">Tips & Trik</a></li>
								</ul>
							</div>					
						</div>
				</div>
		  </div>
		</nav><!-- .site-navigation -->
</header><!-- #masthead -->